# 03. Linux e linha de comando

Foi o maior bloco que estudei e é o que mais uso no dia a dia, tanto em segurança quanto no meu trabalho com infraestrutura. A linha de comando é a interface nativa da segurança ofensiva: é onde a ferramenta roda, onde o alvo é administrado e onde qualquer shell obtida vai desembocar.

Fontes: Formação Hacker (seção 6, 23 aulas) e as sete salas de sistemas operacionais e CLI do TryHackMe (Fundamentos do Linux 1 a 3, linha de comando, segurança do sistema operacional, Windows e CLI do Windows).

## Por que a linha de comando importa

- **Onipresença:** servidor não tem interface gráfica, shell remota também não.
- **Composição:** comandos pequenos combinados por pipe resolvem o que nenhuma ferramenta gráfica cobre.
- **Automação:** o que digito vira script sem reescrever.
- **Auditabilidade:** o comando registra exatamente o que foi feito, essencial em relatório de pentest.

A informação mais importante da tela é saber se estou como usuário comum (`$`) ou root (`#`).

## FHS: onde procurar as coisas

Conhecer o Filesystem Hierarchy Standard é o que me permite, numa máquina desconhecida, saber onde está configuração, credencial, log e binário.

| Diretório | O que guarda e por que olho |
|---|---|
| `/etc` | Configuração. Primeira parada: `passwd`, `shadow`, `hosts`, `crontab`, `ssh/` |
| `/home` | Diretórios pessoais. Chaves SSH, histórico, arquivos de trabalho |
| `/root` | Home do superusuário |
| `/var` | `/var/log` (logs), `/var/www` (sites), `/var/spool` (filas) |
| `/tmp` | Gravável por todos e limpo no boot. Destino comum de payload |
| `/proc` | Info de processo e kernel: `/proc/version`, `/proc/<pid>/` |

## Permissões e os bits que levam a root

Todo arquivo tem dono, grupo e outros, cada um com leitura (4), escrita (2) e execução (1). Isso eu já usava; o que o curso acrescentou foi o peso ofensivo dos bits especiais.

| Bit | Valor | Efeito e relevância |
|---|---|---|
| SUID | 4000 | O binário executa com privilégio do dono. Binário SUID de root mal escrito é o caminho clássico para virar root |
| SGID | 2000 | Executa com o grupo do arquivo |
| Sticky | 1000 | Em diretório compartilhado como `/tmp`, só o dono do arquivo o remove |

A enumeração que sempre rodo numa máquina comprometida:

```bash
find / -perm -4000 -type f 2>/dev/null   # binários SUID
sudo -l                                   # o que posso rodar como root
```

Detalhe que mudou minha forma de administrar: em diretório, `w` permite apagar entradas mesmo sem permissão de escrita no arquivo em si. Isso explica muita falha de configuração que eu via e não entendia.

## Pipes e redirecionamento

O poder real da shell está em encadear os três descritores (stdin, stdout, stderr). Um exemplo que uso de verdade para ler tentativa de invasão em log de autenticação:

```bash
cat /var/log/auth.log | grep "Failed password" | awk '{print $11}' \
  | sort | uniq -c | sort -rn | head -10
```

Essa linha extrai as falhas de autenticação, isola o IP de origem, agrupa, conta e ordena, devolvendo os dez endereços que mais tentaram entrar. Nenhuma ferramenta instalada para isso.

## Texto: grep, awk, sed

`grep -rin "termo" /dir` para busca recursiva, `cut -d: -f1 /etc/passwd` para extrair coluna, `awk '{print $1,$3}'` para processar por campo, `sed -i 's/a/b/g'` para substituir em fluxo, `strings binario` para tirar texto legível de binário. Combinados com `sort -u`, `uniq -c` e `wc -l`, resolvem quase toda pergunta de sala de Linux, que é sempre "quantos", "onde está" ou "o que contém".

## PATH e histórico como vetor

Dois aprendizados que levo para o hardening:

- **PATH:** se um diretório gravável por qualquer usuário aparece antes dos diretórios do sistema no `$PATH`, dá para colocar ali um executável com nome de comando comum e ele roda no lugar do legítimo, inclusive em script privilegiado. Conferir a ordem do `$PATH` é item obrigatório de checklist.
- **Histórico:** `~/.bash_history` de uma máquina comprometida costuma ter senha digitada em linha de comando, host interno e caminho sensível. É uma das primeiras leituras da pós-exploração, e exatamente por isso credencial nunca deve ir como argumento de comando.

## Processos, pacotes e shells

`ps aux`, `ss -tulnp` e `lsof -i` respondem quem está rodando e quem escuta em qual porta. No gerenciamento de pacote, o aprendizado de segurança é sobre confiança: adicionar repositório de terceiro é dar ao mantenedor o direito de instalar software como root a cada atualização, então só adiciono os que tenho razão para confiar.

Quando obtenho uma shell por exploração, ela costuma vir limitada e não interativa. O passo seguinte é estabilizar, tipicamente com `python3 -c 'import pty; pty.spawn("/bin/bash")'`.

## O lado Windows

As salas de Windows cobriram estrutura de diretórios, contas e grupos, permissões NTFS, serviços, registro e os utilitários nativos. O ponto que fica: reconhecimento pós-acesso em Windows começa com o que já está na máquina (`whoami /priv`, `systeminfo`, `net user`), sem instalar nada e sem gerar alerta. Como o parque corporativo é majoritariamente Windows, saber operar ali sem trazer ferramenta externa é o que permite trabalhar em ambiente empresarial.
