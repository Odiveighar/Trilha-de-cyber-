# 10. Comprovação e próximos passos

Este documento fecha a trilha cruzando as duas frentes de estudo, mostrando o que está consolidado, o que ainda é só teoria e qual é o meu plano. É a leitura honesta do percurso, sem inflar o que não está pronto.

## As duas frentes se complementam

O Hackers do Bem entregou base conceitual estruturada, com avaliação formal e certificado. O TryHackMe entregou prática em ambiente controlado, com nove desafios resolvidos sem roteiro. A Formação Hacker amarrou os dois em um ciclo completo de pentest de laboratório.

## Mapa de competências cruzado

| Domínio | Hackers do Bem | TryHackMe | Estado |
|---|---|---|---|
| Redes e protocolos | Nivelamento 3 a 6, pilha TCP/IP | 11 salas, com captura de tráfego | Consolidado nas duas frentes |
| Sistemas operacionais | Nivelamento 7 e 8 | 7 salas de sistema e CLI | Consolidado nas duas frentes |
| Hardware e fundamentos | Nivelamento 2 | 7 salas de fundamentos | Consolidado nas duas frentes |
| Programação e scripts | Nivelamento 9 e 10 | Python, JavaScript, SQL | Consolidado nas duas frentes |
| Computação em nuvem | Básico 1 | Sala de fundamentos de nuvem | Base firme, prática pendente |
| Criptografia | Básico 5 | Conceitos e desafio W1seGuy | Teoria mais um exercício de criptoanálise |
| Ameaças e vulnerabilidades | Básico 3 e 4 | IDOR, LFI, SSRF, bypass | Catálogo teórico com aplicação prática |
| Segurança ofensiva | Introdução no Nivelamento | 7 salas, máquina completa | Concentrado no TryHackMe |
| Segurança defensiva e SOC | Dentro de ameaças e GRC | 6 salas, rotina de analista | Concentrado no TryHackMe |
| Governança, risco, compliance | Básico 6, com LGPD | Sem cobertura direta | Exclusivo do Hackers do Bem |
| IA e segurança de LLM | Sem cobertura direta | 3 salas, injeção indireta de prompt | Exclusivo do TryHackMe |

## Síntese

- **Cobertura ampla e equilibrada.** As duas frentes somam 54 salas práticas e 16 módulos formais, de hardware e pilha de redes até governança e segurança de modelo de linguagem.
- **Teoria com contraparte prática.** Quase todo tema estudado no Hackers do Bem tem exercício correspondente no TryHackMe, o que reduz o risco de conhecimento só declarativo.
- **Comprovação formal.** Dois certificados emitidos, duas conquistas registradas e classificação entre os 5% melhores na plataforma do programa.
- **Diferenciais.** A combinação de governança e LGPD com segurança de LLM é incomum em perfil em formação e cobre os dois extremos da conversa atual do setor.

## Onde eu ainda não tenho registro (e é honesto dizer)

- **Active Directory e PowerShell.** É o terreno da maior parte dos engajamentos corporativos e onde meu perfil ainda não tem prática registrada.
- **SQL injection na prática.** A base teórica de SQL está feita, falta o exercício ofensivo correspondente.
- **Forense e análise de memória.** Complemento natural do bloco defensivo que já iniciei.
- **Exploração de binário.** A base de arquitetura e representação de dados já está construída.
- **Nuvem na prática.** Levar a segurança em nuvem do conceito para laboratório de configuração incorreta de identidade e armazenamento.

## Meu plano

Na ordem em que pretendo fechar:

1. SQL injection prático, aproveitando a base de SQL e o catálogo de vulnerabilidades.
2. Active Directory e PowerShell, por ser o terreno corporativo.
3. Forense digital e análise de memória, complementando o bloco defensivo.
4. Exploração de binário, sobre a base de arquitetura que já tenho.
5. Segurança em nuvem na prática.

No horizonte de certificação, o caminho que faz sentido para mim é entrada com Security+ e eJPT, depois prática com OSCP ou PNPT. O princípio que sustenta isso: ferramenta muda, fundamento permanece. Quem domina Linux, redes, lógica e metodologia aprende qualquer ferramenta nova em dias.

## Como me encontrar

- TryHackMe: perfil Odivighar
- Freelance: 99Freelas e Workana (automação e cibersegurança)
