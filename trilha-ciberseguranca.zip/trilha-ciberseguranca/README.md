# Minha trilha em cibersegurança

Sou o Odivan Souza. Este repositório é o registro consolidado da formação que venho construindo em segurança da informação: o que estudei, onde pratiquei, o que consegui resolver sozinho e o que ainda falta.

Não é um catálogo de certificados. É a documentação técnica do percurso, escrita por mim, com o conteúdo de cada bloco, a competência prática que ele deixou e a leitura honesta das lacunas que ainda existem. Quem abrir este repositório deve conseguir avaliar o que eu sei fazer sem precisar acreditar na minha palavra.

## Números do percurso

| Frente | Volume | Situação |
|---|---|---|
| TryHackMe (perfil Odivighar) | 54 salas concluídas, nível 0x7 | Top 15% da plataforma |
| Desafios sem passo a passo | 9 salas resolvidas | Aplicação autônoma |
| Hackers do Bem (MCTI, Softex, SENAI, RNP) | Nivelamento 80h + Básico 64h, 16 módulos | Concluído com certificado |
| Formação Hacker (SecVox Academy) | 22h, 127 aulas, 18 seções | Concluído, 100% |
| Aceleração Santander em Cibersegurança (DIO) | Do zero à prática, incluindo segurança em Vibe Coding | Concluído |
| Classificação no AVA do Hackers do Bem | 7.534º de 149.868 | Aproximadamente top 5% |

## Como este repositório está organizado

| Documento | O que cobre |
|---|---|
| [01. Fundamentos e metodologia](docs/01-fundamentos-e-metodologia.md) | Tríade CIA, vocabulário de risco, as cinco fases do hack, modelagem de ameaça, ética e legislação brasileira |
| [02. Laboratório](docs/02-laboratorio.md) | Como montei e isolei meu ambiente de testes: VirtualBox, Kali, Metasploitable 2 e 3, topologia de rede |
| [03. Linux e linha de comando](docs/03-linux-e-shell.md) | FHS, permissões, bits especiais, pipes, processos, texto, pacotes e o uso ofensivo de cada um |
| [04. Redes e aplicações web](docs/04-redes-e-web.md) | OSI e TCP/IP, handshake, flags TCP, DNS, HTTP, cookies, análise de tráfego |
| [05. OSINT e Google Dorking](docs/05-osint-e-google-dorking.md) | Ciclo de inteligência, WHOIS, metadados, Wayback, operadores de busca, higiene do investigador |
| [06. Vulnerabilidades e pentest](docs/06-vulnerabilidades-e-pentest.md) | CVE, CWE, CVSS, Nmap, OpenVAS, Metasploit, escalação de privilégios, quebra de hashes |
| [07. Defensivo, SOC e governança](docs/07-defensivo-soc-e-grc.md) | Rotina de analista, níveis de SOC, controles, gestão de risco, LGPD |
| [08. IA e segurança de LLM](docs/08-ia-e-seguranca-de-llm.md) | Modelagem de ameaças em sistemas com IA e injeção indireta de prompt |
| [09. Desafios que resolvi](docs/09-desafios-resolvidos.md) | Os 9 desafios sem roteiro, descritos pela classe de vulnerabilidade, sem entregar solução |
| [10. Comprovação e próximos passos](docs/10-comprovacao-e-proximos-passos.md) | Mapa cruzado das duas frentes, o que está consolidado, o que falta e o plano |

## O que este percurso me deixou na prática

Eu trabalho com automação e infraestrutura no dia a dia (n8n, Docker Swarm, Traefik, Supabase, APIs), e a formação em segurança mudou a forma como eu construo essas coisas. Três exemplos concretos do que passou a ser rotina no meu trabalho:

1. **Superfície de ataque antes da entrega.** Toda automação que eu subo passa por uma checagem de portas expostas, credenciais em variável de ambiente em vez de código, permissão mínima no banco e cabeçalhos de segurança no que é servido por HTTP.
2. **Segurança de agentes com LLM.** Como construo bots e agentes conectados a ferramentas, injeção indireta de prompt deixou de ser assunto teórico. Eu trato conteúdo lido pelo agente como dado, nunca como instrução, e imponho essa fronteira na arquitetura da aplicação e não no prompt de sistema.
3. **Documentação como entregável.** Aprendi na parte de pentest que achado sem evidência, passo de reprodução e recomendação de correção não vale nada. Aplico o mesmo padrão em revisão de segurança de painéis e sistemas de clientes.

## Ética e escopo

Todo o conteúdo aqui é de estudo. Pratiquei exclusivamente em laboratório próprio e isolado, em plataformas que autorizam explicitamente o teste (TryHackMe) e dentro de escopo contratado, com autorização por escrito. No Brasil, invadir dispositivo informático sem autorização é crime (Lei 12.737/2012, art. 154-A do Código Penal), e o tratamento de dados pessoais é regido pela LGPD (Lei 13.709/2018). A diferença entre o profissional e o criminoso não está na técnica, que é a mesma. Está na autorização.

Nos desafios de CTF, descrevo a classe de vulnerabilidade e o raciocínio, sem publicar solução ou flag.
