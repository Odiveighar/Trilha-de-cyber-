# 07. Defensivo, SOC e governança

O contraponto azul da minha formação. Estudar ataque sem entender defesa é metade do quadro, então dediquei um bloco à rotina de quem defende, à estrutura de um SOC e à camada de governança que sustenta tudo.

Fontes: seis salas de segurança defensiva e SOC do TryHackMe e os módulos de ameaças, criptografia e GRC do Básico do Hackers do Bem.

## A assimetria entre atacar e defender

A lição central: defender exige cobrir toda a superfície, atacar exige achar um ponto. Essa assimetria é o que justifica defesa em profundidade, com controles em camadas em vez de um muro único. Os controles se dividem em preventivo, detectivo e corretivo, e nenhum substitui os outros.

## A rotina real de um analista

As salas de analista júnior e função SOC me mostraram que o trabalho real não é resolver tudo sozinho, é priorização sob volume. O SOC se organiza em níveis (Tier 1 a Tier 3) justamente para filtrar volume, e a progressão vai de triagem reativa para caça proativa a ameaça.

O que fica para mim como quem constrói sistema: saber quando escalar um incidente e documentar por quê vale mais do que heroísmo individual. E o analista decide o tempo todo sobre falso positivo, o que reforça que alerta sem contexto é ruído.

## Ameaças que realmente acontecem

O módulo de ameaças do Hackers do Bem cobriu as famílias de malware (vírus, worm, trojan, ransomware, spyware), phishing e engenharia social, negação de serviço, ataque a credencial e APT. O dado que mudou minha priorização: a maioria dos incidentes começa por engenharia social, não por exploração técnica sofisticada. Isso desloca parte relevante do investimento de defesa para conscientização e controle de identidade, e é exatamente o conselho que dou para cliente pequeno.

## Criptografia aplicada

Estudei simétrica contra assimétrica, função de hash, assinatura digital, PKI e certificado, TLS, VPN e cifragem em repouso e em trânsito. A distinção que uso o tempo todo: hash é unidirecional e serve à integridade; cifra é reversível com a chave e serve à confidencialidade; codificação (Base64, URL-encoding) não é nenhum dos dois e é reversível por qualquer um. Confundir hash com cifra é a origem de boa parte das falhas de armazenamento de senha.

E o ponto frágil quase nunca é o algoritmo. É a gestão das chaves e a configuração do protocolo. Isso orienta como eu trato segredo em automação: o cuidado vai para onde a chave é guardada e como ela roda, não para escolher o algoritmo mais na moda.

## Governança, risco e compliance

O módulo de GRC, com LGPD, é uma cobertura que meu perfil tem e que é rara em quem está começando. O aprendizado que sintetiza o bloco: controle técnico sem política que o sustente não se mantém ao longo do tempo. Governança é o que dá autoridade, orçamento e continuidade às medidas de segurança, e é também o que traduz risco técnico em linguagem de negócio.

Vulnerabilidade só vira risco quando existe ameaça capaz de explorá-la e ativo com valor exposto. Priorizar correção por severidade combinada com exposição real é mais eficaz do que tentar corrigir tudo. É a mesma lógica de risco do bloco de fundamentos, aplicada agora do lado de quem administra o programa de segurança.

## Nuvem e responsabilidade compartilhada

A fronteira de responsabilidade muda conforme o modelo (IaaS, PaaS, SaaS): quanto mais o provedor gerencia, menos superfície sobra para o cliente, mas configuração de identidade e acesso permanece sempre com o cliente. A maioria dos vazamentos em nuvem é erro de configuração do lado do cliente, não falha do provedor. Como trabalho com serviço hospedado, isso é diretamente aplicável: a conta e a configuração são minha responsabilidade, não do provedor.
