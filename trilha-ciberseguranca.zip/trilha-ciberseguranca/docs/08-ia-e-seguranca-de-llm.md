# 08. IA e segurança de LLM

Este é o bloco mais recente do meu perfil e o que mais se conecta com o meu trabalho, já que construo bots e agentes conectados a ferramentas. É também um diferencial: injeção indireta de prompt e modelagem de ameaça em LLM ainda são raros em perfil em formação.

Fontes: três salas de IA e segurança de LLM do TryHackMe (fundamentos de IA, modelagem de ameaças de IA e LLMborghini) e minha aplicação direta disso no dia a dia com automação.

## Por onde vem a superfície de ataque

O ponto de partida: um LLM prevê a continuação mais provável, não consulta uma base de verdade. Toda a superfície de ataque desses sistemas decorre disso. Ele não sabe distinguir sozinho o que é dado do que é instrução, e essa é a raiz de quase toda falha.

## Modelagem de ameaça acrescenta ativos novos

A sala de modelagem me mostrou que sistema com IA adiciona ativos que não existiam no inventário tradicional: o modelo, os dados de treinamento e o próprio prompt de sistema. As ameaças específicas que estudei:

- **Envenenamento de dados de treinamento:** corromper o que o modelo aprende.
- **Extração de modelo:** reconstruir o modelo a partir de suas respostas.
- **Vazamento de prompt de sistema:** fazer o modelo revelar as instruções que o governam.
- **Abuso de ferramenta conectada:** as ferramentas que o agente aciona ampliam o impacto de qualquer injeção bem-sucedida.

Esse último ponto é o que mais me afeta: um agente que só conversa tem impacto limitado; um agente que pode ler e-mail, escrever em banco ou disparar mensagem transforma uma injeção em ação real.

## Injeção indireta de prompt

A sala LLMborghini foi sobre a lição central: a diferença entre injeção direta e indireta. Na direta, alguém instrui o modelo de frente. Na indireta, planta a instrução em conteúdo que o modelo vai ler (uma página, um documento, um campo) e consegue que ele a execute como se fosse comando legítimo.

O aprendizado que carrego textualmente: o modelo não separa dado de instrução por conta própria. Essa fronteira precisa ser imposta pela arquitetura da aplicação, não pedida no prompt de sistema. Pedir educadamente ao modelo para não obedecer instrução embutida não é controle de segurança.

## Como isso mudou meu trabalho

Eu construo agentes com LLM conectados a ferramentas (n8n, WhatsApp, APIs). Antes desse bloco, minha proteção era escrever um prompt de sistema caprichado. Depois dele, mudei a abordagem:

1. **Conteúdo lido pelo agente é dado, nunca comando.** Mensagem de usuário, resultado de ferramenta e documento externo entram como dado a ser processado, com a fronteira imposta na aplicação.
2. **Menor privilégio na ferramenta.** O agente só tem acesso à ferramenta e à permissão que a tarefa exige. Se ele não precisa apagar, não recebe permissão de apagar.
3. **Confirmação em ação irreversível.** Ação com efeito colateral (enviar, publicar, apagar, mover dinheiro) passa por confirmação explícita, porque uma injeção bem-sucedida não deve conseguir disparar isso sozinha.

É a mesma lógica de validar no servidor que aparece nos desafios web: não se confia em quem manda a entrada, seja o navegador ou o conteúdo que o modelo lê.
