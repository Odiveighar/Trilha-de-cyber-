# Post para LinkedIn

Passei os últimos meses construindo uma trilha em cibersegurança de forma deliberada, e acabei de documentar tudo em um repositório público.

Não é uma lista de certificados. É a documentação técnica do que estudei, o que pratiquei e o que consegui resolver sozinho, escrita por mim, com a leitura honesta do que ainda falta.

Os números do percurso:

- 54 salas concluídas no TryHackMe (perfil Odivighar), nível 0x7, top 15%
- 9 desafios resolvidos sem passo a passo, do alvo direto à flag
- Programa Hackers do Bem (MCTI, Softex, SENAI, RNP): trilhas Nivelamento e Básico concluídas com certificado, top 5% entre quase 150 mil participantes
- Formação Hacker (SecVox Academy): 127 aulas, ciclo completo de pentest em laboratório
- Aceleração Santander em Cibersegurança (DIO)

O que cobri: fundamentos e metodologia, laboratório isolado, Linux e linha de comando, redes e web, OSINT, vulnerabilidades e pentest de ponta a ponta, o lado defensivo com SOC e governança (incluindo LGPD) e um bloco de segurança de LLM que é raro em quem está começando.

O que mais me interessa é onde isso encontra o meu trabalho. Eu construo automações e agentes com IA conectados a ferramentas, e o bloco de injeção indireta de prompt deixou de ser teoria: conteúdo que o agente lê é dado, nunca comando, e essa fronteira se impõe na arquitetura, não no prompt.

A documentação completa está no repositório, com um documento por domínio e um mapa cruzado do que está consolidado e do que vem a seguir.

Aberto a conversas sobre automação segura e segurança ofensiva.

[link do repositório]

#cibersegurança #pentest #segurançadainformação #tryhackme #LGPD #automação
