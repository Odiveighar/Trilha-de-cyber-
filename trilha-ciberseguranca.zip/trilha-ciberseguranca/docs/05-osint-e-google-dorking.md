# 05. OSINT e Google Dorking

OSINT é a fase 1 do hack e uma especialidade por si só. Estudei como coletar, correlacionar e analisar informação pública para transformar dado solto em inteligência acionável, e como o buscador vira ferramenta de reconhecimento cirúrgico.

Fontes: Formação Hacker (seções 7 a 12), incluindo privacidade e anonimato, OSINT e Google Dorking.

## O ciclo de inteligência

OSINT não é sair coletando. É um ciclo com direção:

1. **Direção:** definir o objetivo e as perguntas. Sem alvo, coleta vira acúmulo inútil.
2. **Coleta:** reunir dado com registro rigoroso de origem e data.
3. **Processamento:** organizar, traduzir, extrair metadado, normalizar.
4. **Análise:** correlacionar, validar evitando confirmação enviesada, transformar dado em informação.
5. **Disseminação:** relatar claro a quem decide.

A arte está na correlação de dados isolados e inofensivos que, somados, revelam algo sensível. E o critério de parada é responder às perguntas da fase de direção, não "acabar a internet".

## O princípio do pivô

Todo dado é uma ponte para o próximo. Um apelido leva a perfis em várias plataformas; um perfil expõe um e-mail; o e-mail aparece num vazamento e num registro de domínio; o domínio revela a infraestrutura. A investigação avança em rede, não em linha.

## Ferramentas que aprendi a usar

| Ferramenta | Para quê |
|---|---|
| WHOIS | Registrante, datas, servidores de nome. WHOIS reverso pivota para outros domínios da mesma pessoa |
| Wayback Machine | Recupera conteúdo removido, versões antigas do site, e-mails e funcionários apagados |
| exiftool | Metadado de foto e documento: modelo do dispositivo, data, GPS, autor, software |
| Have I Been Pwned | Verifica se um e-mail apareceu em vazamento, indica risco de reuso de senha |
| Shodan / Censys | Buscadores de dispositivo conectado, encontram servidor e serviço exposto por banner |
| Sherlock / WhatsMyName | Testam um apelido em centenas de plataformas |
| OSINT Framework | Índice de por onde começar para cada tipo de dado inicial |

Sobre metadado, o aprendizado tem os dois lados: EXIF de foto frequentemente traz coordenada GPS, e documento de Office ou PDF carrega autor, organização e caminho de arquivo. A contramedida que aplico é sanitizar metadado antes de publicar qualquer arquivo, inclusive nos materiais que produzo para clientes.

## Google Dorking

Operadores de busca localizam o que não deveria estar exposto. Os que uso:

| Operador | Função |
|---|---|
| `site:` | Restringe a um domínio |
| `filetype:` / `ext:` | Filtra por tipo de arquivo |
| `intitle:` | Termo no título, ex. `intitle:"index of"` |
| `inurl:` | Termo na URL, ex. `inurl:admin` |
| `intext:` | Termo no corpo |

O `robots.txt` é um paradoxo útil: para esconder um diretório dos buscadores, o administrador o lista publicamente. Para quem faz recon, o arquivo é o mapa dos caminhos que o dono considera sensíveis. É a prova de que segurança por obscuridade não é segurança, e uma das primeiras coisas que leio num alvo web.

O GHDB, mantido pela Exploit-DB, cataloga dorks por categoria: arquivo com senha, diretório sensível, mensagem de erro reveladora, dispositivo online, portal de login.

## Privacidade e higiene do investigador

Estudei a diferença entre surface, deep e dark web e entre privacidade (ninguém vê o que você faz) e anonimato (ninguém sabe que é você). A regra que sustenta tudo: anonimato é comportamento, não ferramenta. Uma única ação identificável anula o melhor arranjo técnico.

Ao fazer OSINT, separo a identidade real da identidade de pesquisa: VM dedicada, conta descartável, sem login em serviço pessoal, e consciência de que visitar o alvo pode alertá-lo. Reconhecimento passivo não deixa rastro no alvo; ativo deixa. Essa distinção é o que mantém uma investigação limpa e defensável.

## O limite ético

Encontrar informação exposta por dork é reconhecimento passivo legítimo. Acessar, baixar ou usar o que foi encontrado sem autorização é acesso não autorizado e crime, independentemente de o Google ter mostrado o caminho. A dork mostra a porta aberta; entrar por ela sem permissão continua sendo invasão.
