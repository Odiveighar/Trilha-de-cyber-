# Como publicar este repositório no GitHub

Não tenho um connector do GitHub ligado aqui, então não consegui criar o repositório e dar push por você. Mas deixei tudo pronto: é só rodar os comandos abaixo. Leva menos de um minuto.

## Opção 1: com a CLI do GitHub (mais rápido)

Se você tem o `gh` instalado e autenticado:

```bash
cd trilha-ciberseguranca
git init
git add .
git commit -m "Trilha documentada em ciberseguranca"
gh repo create trilha-ciberseguranca --public --source=. --push
```

Pronto. O comando cria o repositório na sua conta e já faz o push.

## Opção 2: pelo site + git

1. Crie um repositório vazio em https://github.com/new com o nome `trilha-ciberseguranca` (deixe sem README, sem .gitignore).
2. Rode:

```bash
cd trilha-ciberseguranca
git init
git add .
git commit -m "Trilha documentada em ciberseguranca"
git branch -M main
git remote add origin https://github.com/SEU-USUARIO/trilha-ciberseguranca.git
git push -u origin main
```

Troque `SEU-USUARIO` pelo seu usuário do GitHub.

## Depois de publicar

- O `README.md` já aparece formatado na página inicial do repositório, com a tabela de números e os links para cada documento.
- Pegue a URL do repositório e cole no lugar de `[link do repositório]` no arquivo `linkedin/post-linkedin.md` antes de postar.

Se quiser, na próxima conversa você pode conectar o GitHub nas configurações de connectors e eu publico direto.
