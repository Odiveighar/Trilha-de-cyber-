# 04. Redes e aplicações web

Segundo maior bloco da minha formação e o mais denso do meu perfil no TryHackMe. A premissa que carrego daqui: não se compromete nem se defende o que não se entende, e toda técnica acontece sobre um protocolo.

Fontes: Formação Hacker (seção 9, 28 aulas), Hackers do Bem (Nivelamento, módulos 3 a 6, pilha TCP/IP completa) e 11 salas de redes e protocolos web do TryHackMe, incluindo a sala de captura de tráfego.

## OSI como mapa de diagnóstico

Decorei as sete camadas, mas o valor prático é usar o OSI para isolar onde um problema ou ataque está, em vez de tratar a rede como caixa-preta.

| Camada | Função | Ataques associados |
|---|---|---|
| 7 Aplicação | Interface com usuário e software | SQLi, XSS, phishing |
| 6 Apresentação | Formato, codificação, cifra | Downgrade de cifra |
| 5 Sessão | Estabelece e encerra sessão | Sequestro de sessão |
| 4 Transporte | Entrega fim a fim, portas | Varredura de porta, SYN flood |
| 3 Rede | Endereçamento lógico e rota | IP spoofing, ping sweep |
| 2 Enlace | Endereçamento físico local | ARP spoofing, MAC flooding |
| 1 Física | Sinal | Grampo físico, jamming |

Quando investigo uma falha, percorro de baixo para cima: cabo e sinal, MAC, IP e rota, porta e serviço, aplicação. O TCP/IP é o que a internet realmente implementa; o OSI é o modelo para ensinar e diagnosticar.

## O handshake e por que importa na varredura

TCP sincroniza número de sequência em três passos (SYN, SYN-ACK, ACK) antes de qualquer dado. Isso não é trivia, é a base de como o Nmap lê uma porta:

- Porta aberta responde SYN-ACK.
- Porta fechada responde RST.
- Porta filtrada não responde, ou devolve ICMP unreachable, sinal de firewall.

Um SYN scan (`nmap -sS`) envia SYN, lê a resposta e manda RST sem completar o handshake, sendo mais rápido e menos registrado que a conexão completa. As varreduras evasivas (NULL, FIN, Xmas) exploram diferenças de implementação da pilha TCP entre sistemas.

## Portas que sempre verifico

| Porta | Serviço | Observação |
|---|---|---|
| 21 | FTP | Credencial em texto claro, login anônimo comum em alvo vulnerável |
| 22 | SSH | Alvo de força bruta, exige chave e desativar login root |
| 23 | Telnet | Texto claro, não deveria existir em rede moderna |
| 53 | DNS | Transferência de zona mal configurada expõe a rede inteira |
| 80 / 443 | HTTP / HTTPS | Maior superfície de ataque da internet |
| 139 / 445 | NetBIOS / SMB | Origem de falha crítica como EternalBlue |
| 3306 / 5432 | MySQL / PostgreSQL | Banco jamais deve estar exposto |
| 3389 | RDP | Alvo preferencial de ransomware |

## DNS como fonte de reconhecimento

O DNS é banco de dados distribuído, e sua estrutura vira material de recon. Os registros que mais entregam:

| Registro | Relevância ofensiva |
|---|---|
| A / AAAA | Servidor real. AAAA costuma ser esquecido pelo firewall |
| CNAME | Revela terceiro e SaaS usados, base de subdomain takeover |
| MX | Provedor de e-mail, alvo de phishing |
| TXT | SPF, DKIM, DMARC e tokens vazam serviços usados |
| NS | Alvo de tentativa de transferência de zona (AXFR) |

Uma transferência de zona permitida entrega o mapa completo dos hosts do domínio e é uma das descobertas mais valiosas do reconhecimento. Ferramentas: `dig alvo ANY`, `dig alvo MX`, `dig alvo TXT`, `dig alvo AXFR @ns1.alvo`.

## HTTP, status e cabeçalhos

HTTP é sem estado, por isso existem cookie, token e sessão. Na enumeração, a diferença entre respostas é o que informa: 403 em vez de 404 confirma que o recurso existe; 500 numa entrada específica sinaliza que o parâmetro chega ao backend sem validação; variação de tempo de resposta revela consulta ao banco.

Os cabeçalhos de segurança que eu checo estarem presentes (e configuro quando sirvo algo por HTTP):

- `Strict-Transport-Security` obriga HTTPS nas visitas seguintes.
- `Content-Security-Policy` restringe origem de script, principal mitigação de XSS.
- `X-Frame-Options` impede embutir em iframe, contra clickjacking.
- `X-Content-Type-Options: nosniff` impede o navegador de adivinhar o tipo.
- `Server` e `X-Powered-By` revelam tecnologia e versão, então suprimo.

## Cookies e sessão

Um cookie de sessão roubado equivale à senha: quem o possui é o usuário, sem precisar autenticar. Daí a combinação obrigatória `HttpOnly; Secure; SameSite` e a rotação do identificador após o login. `HttpOnly` impede acesso via JavaScript e é a mitigação central contra roubo de sessão por XSS.

## curl como bisturi

Uso `curl` para inspecionar comportamento HTTP na mão: `curl -I` para só cabeçalho, `curl -v` para a negociação inteira, `curl -X OPTIONS -i` para ver métodos permitidos, `curl -b "sessao=..."` para enviar cookie. É a ferramenta que confirma hipótese sobre a aplicação sem depender de nenhuma automação.

## Análise de tráfego

A sala de tráfego fechou o ciclo com uma lição que carrego: onde se coleta define o que se enxerga. Captura com tcpdump e Wireshark vira ruído em segundos se não filtrar antes de olhar, e a diferença entre dados de fluxo e captura completa de pacotes muda completamente o que dá para investigar depois.
