# 01. Fundamentos e metodologia

Este foi o primeiro bloco que estudei e é o que sustenta todo o resto. Cobre o vocabulário, os modelos mentais e o enquadramento legal que eu uso antes de encostar em qualquer sistema.

Fontes: Formação Hacker (seções 1 a 3), Hackers do Bem (Nivelamento, módulo 1) e as salas de tríade CIA, fundamentos de pentesting e carreiras do TryHackMe.

## A tríade CIA e como eu a uso

Segurança da informação protege a informação em trânsito, em repouso e em processamento. Os três pilares:

| Pilar | O que garante | Como falha na prática |
|---|---|---|
| Confidencialidade | Só quem tem autorização acessa | Vazamento de banco, bucket público, tráfego sem cifra |
| Integridade | O dado não é alterado sem autorização, e alteração legítima é rastreável | Defacement, adulteração de registro, man in the middle |
| Disponibilidade | O dado está acessível a quem tem direito, quando precisa | DoS, ransomware, backup que nunca foi testado |

A extensão clássica acrescenta autenticidade, não repúdio e conformidade legal.

O que eu tirei disso não é a definição, é o hábito: antes de qualquer teste eu pergunto qual pilar está sendo avaliado. Teste que derruba serviço avalia disponibilidade, e isso quase sempre está fora de escopo em produção sem janela combinada e autorização explícita. Reforçar um pilar quase sempre custa outro, então toda decisão de segurança é uma escolha consciente, não um ganho puro.

## Vocabulário que eu uso com precisão

| Termo | Definição que adoto |
|---|---|
| Ativo | Qualquer coisa de valor: dado, servidor, credencial, reputação, pessoa |
| Ameaça | Agente ou evento com potencial de causar dano ao ativo |
| Vulnerabilidade | Fraqueza explorável. Existe mesmo que ninguém a explore |
| Exploit | Técnica ou código que transforma a vulnerabilidade em efeito concreto |
| Payload | A carga que executa no alvo depois da exploração |
| Risco | Probabilidade multiplicada por impacto. Risco é o que se gerencia, vulnerabilidade é o que se corrige |
| Superfície de ataque | Todos os pontos por onde alguém não autorizado pode tentar entrar |
| Vetor de ataque | O caminho concreto usado: phishing, porta exposta, dependência vulnerável, pessoa de dentro |
| Zero-day | Falha sem correção disponível e, em geral, desconhecida do fornecedor |
| Escalação de privilégios | Passar de contexto limitado para root ou SYSTEM (vertical), ou para outro usuário do mesmo nível (horizontal) |
| Pivoting | Usar máquina já comprometida como ponte para redes não alcançáveis de fora |
| Hardening | Redução deliberada da superfície: desligar serviço, fechar porta, remover conta padrão |
| IoC | Artefato observável (hash, IP, domínio, chave de registro) que sinaliza comprometimento |

A distinção que mais uso no trabalho é vulnerabilidade contra risco. Já corrigi lista de vulnerabilidade em ordem de nota CVSS e aprendi que isso é ineficiente: falha média em sistema crítico e exposto vale mais atenção que falha alta em serviço isolado sem dado sensível.

## Tipos de agente

A classificação por chapéu separa por autorização e intenção, nunca por técnica.

- **White hat:** atua sob contrato e escopo, reporta e ajuda a corrigir. É o papel que eu ocupo.
- **Black hat:** criminoso, com motivação financeira, sabotagem ou espionagem.
- **Gray hat:** encontra e divulga sem permissão. Mesmo sem dolo, a conduta é ilegal na maior parte das jurisdições.
- **Script kiddie:** usa ferramenta pronta sem entender o mecanismo. Muito ruído, pouca sofisticação.
- **Hacktivista:** motivação política, com ataques de visibilidade.
- **Insider:** acesso legítimo usado de forma abusiva. Difícil de pegar com controle de perímetro.
- **APT patrocinada por Estado:** alta capacidade, persistência longa, uso de zero-day.
- **Red, blue e purple team:** simulação do adversário, defesa e o processo que faz os dois trocarem conhecimento.

## As cinco fases do hack

É o esqueleto que eu sigo em qualquer exercício.

| Fase | O que acontece | O que eu uso |
|---|---|---|
| 1. Reconhecimento | Coleta de informação. Passivo, sem tocar o alvo, ou ativo, com interação direta | OSINT, WHOIS, dorks, Wayback, DNS, banner |
| 2. Varredura | Hosts vivos, portas, serviços, versões, sistema operacional, falhas conhecidas | Nmap, OpenVAS |
| 3. Obtenção de acesso | Exploração da falha para conseguir execução ou sessão | Metasploit, exploits públicos, ataque a credencial |
| 4. Manutenção do acesso | Persistência. Em teste autorizado, tudo é registrado e removido no fim | Backdoor, conta extra, chave SSH, tarefa agendada |
| 5. Rastros | No crime, apagar. No teste ético, o oposto: preservar evidência e devolver o ambiente ao estado original | Registro, evidência, limpeza documentada |

A lição que mais mudou meu resultado: a maior parte do tempo de um teste bem feito fica nas fases 1 e 2. Exploração é consequência de reconhecimento. Quem pula a enumeração acaba tentando exploit às cegas, gera ruído e não acha o caminho mais curto. Isso se confirmou em cada máquina que resolvi.

## Motivadores e modelagem de ameaça

Entender a motivação é o que permite dimensionar controle. Financeiro é de longe o mais comum (ransomware, fraude, revenda de dado, extorsão por vazamento), seguido de espionagem, motivação ideológica, conflito interno, ego e curiosidade.

O modelo de ameaça de uma clínica de bairro não é o de uma distribuidora de energia. Sem essa distinção, o dinheiro vai para o lugar errado. Uso isso diretamente com clientes pequenos: para a maioria deles, o adversário plausível é phishing, credencial reutilizada e conta de rede social sequestrada, e não um ataque sofisticado de rede.

## Ética e legislação brasileira

Três elementos definem um teste legítimo:

1. **Autorização por escrito**, dada por quem tem poder para conceder, que é o dono do sistema e não um funcionário qualquer.
2. **Escopo definido:** quais alvos, quais técnicas, qual janela de tempo e o que está explicitamente fora.
3. **Regras de engajamento:** limites, contato de emergência, tratamento de dado sensível encontrado e procedimento em caso de comprometimento acidental.

No Brasil, invadir dispositivo informático sem autorização é crime tipificado pela Lei 12.737/2012, que alterou o Código Penal (art. 154-A). Somam-se a LGPD (Lei 13.709/2018) e o Marco Civil da Internet (Lei 12.965/2014). Testar sistema de terceiro sem contrato, mesmo com boa intenção e sem causar dano, expõe a responsabilização penal e civil.

Encontrar exposição por meio de busca avançada é reconhecimento passivo legítimo. Acessar, baixar ou usar o que foi encontrado sem autorização continua sendo invasão, mesmo que o buscador tenha mostrado o caminho.

## Metodologia formal

Estudei as modalidades caixa-preta, caixa-cinza e caixa-branca e as metodologias OSSTMM, OWASP e NIST. Metodologia não existe por burocracia: ela garante cobertura e torna o resultado reproduzível por outra pessoa. Um teste que não pode ser repetido não pode ser verificado, e um achado que não pode ser verificado não vira correção.
