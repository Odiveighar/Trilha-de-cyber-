# 09. Desafios que resolvi sem roteiro

Este é o documento que eu considero o mais forte do meu perfil. Sala com passo a passo mostra exposição; desafio sem roteiro mostra aplicação autônoma. São nove desafios do TryHackMe em que havia só o alvo e a flag, sem instrução.

Descrevo cada um pela classe de vulnerabilidade e pelo raciocínio, sem publicar solução ou flag, porque essa é a conduta correta em CTF ativo.

## Aplicação web

**Vizinho (IDOR).** Serviço de autenticação em que o identificador do usuário trafegava como parâmetro controlável pelo cliente. Referência direta insegura a objeto na forma mais limpa: a aplicação autenticava mas não autorizava. Reforçou o hábito de ler o código-fonte da página, porque comentário esquecido no HTML entregava o ponto de partida. A correção é validar autorização no servidor, não só autenticação.

**Lo-Fi (LFI por travessia de diretório).** Site que carregava conteúdo por um parâmetro de página; manipular esse parâmetro fazia o servidor ler arquivo fora do diretório previsto. Aprendi que qualquer parâmetro que vira caminho no servidor precisa ser validado contra lista de permissão, porque filtrar sequência de escape isoladamente não basta.

**MD2PDF (SSRF).** Conversor de Markdown para PDF que renderizava no servidor o conteúdo enviado, incluindo referência a recurso externo. O conversor fazia requisição em nome do atacante e, a partir do próprio servidor, alcançava serviço interno não exposto na rede. A lição: todo renderizador que aceita entrada do usuário é um cliente HTTP em potencial.

## Criptoanálise

**W1seGuy (XOR com chave curta).** Cifra XOR com chave curta sobre texto claro de formato conhecido. Como o prefixo da flag era previsível, o XOR do texto cifrado com esse prefixo revelava parte da chave, e o resto saía por força bruta. É um ataque de texto claro conhecido, e a conclusão é direta: XOR com chave curta e reutilizada não oferece segurança nenhuma.

## Bypass de proteção

**Ignorar funções desativadas.** Ambiente com as funções perigosas de execução de comando desativadas por configuração, e o objetivo era obter execução mesmo assim. Confirmou que lista de bloqueio é defesa frágil: sempre sobra caminho alternativo para a mesma capacidade, e a mitigação real está em isolar o processo, não em enumerar o que proibir.

**Companheiro de tolos.** Desafio de contornar o mecanismo de verificação que decide o que é permitido processar. O motor de validação também é código com estado e caso de borda, e explorar a diferença entre o que o filtro entende e o que o sistema de fato executa é o padrão por trás de quase todo bypass.

## Análise e escape

**O lago de pesca.** Cenário de isca: identificar o artefato malicioso e extrair a informação sem cair no mecanismo preparado para o analista. Análise de artefato suspeito começa por inspeção estática, olhando cabeçalho do arquivo, strings e metadado antes de qualquer execução. Pressa é exatamente o que o cenário explora.

**Corredor.** Ambiente restrito do qual era preciso escapar, encadeando descobertas até sair. Escapar de contexto restrito depende de enumerar exaustivamente o que ainda é permitido. A saída quase nunca é uma falha grande, é a soma de várias permissões pequenas.

**O jogo.** Hacking de jogo: alterar o estado da aplicação em execução para obter resultado que a lógica original não permitia. É a mesma lição do módulo web aplicada a binário em memória em vez de requisição HTTP, e a razão pela qual lógica de negócio precisa ser validada no servidor.

## O que esses nove têm em comum

Quase todos apontam para a mesma raiz: não se confia na entrada, venha ela do navegador, de um parâmetro, de um arquivo ou do estado do cliente. E o método que resolveu a maioria não foi um exploit espetacular, foi enumeração exaustiva antes de tentar qualquer coisa. É a mesma disciplina das cinco fases, agora sem ninguém dizendo o caminho.
