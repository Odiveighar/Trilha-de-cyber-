# 02. Laboratório

Antes de qualquer prática, montei um ambiente próprio, isolado e reversível. Este documento registra como fiz e por que cada decisão importa, porque a montagem do laboratório já é meia dúzia de conceitos de segurança aplicados.

Fontes: Formação Hacker (seção 5) e as salas de virtualização do TryHackMe.

## Por que montei um laboratório

Quatro razões, todas práticas:

- **Legalidade.** Testar contra sistema de terceiro sem autorização é crime. No laboratório o alvo é meu.
- **Isolamento.** As máquinas propositalmente vulneráveis não podem tocar a internet nem minha rede doméstica.
- **Reversibilidade.** Snapshot me deixa quebrar tudo e voltar ao estado anterior em segundos.
- **Repetibilidade.** Consigo refazer o mesmo cenário até entender a técnica, em vez de decorar.

## Topologia que adotei

Uso VirtualBox como hipervisor tipo 2 com o Extension Pack na mesma versão. A regra de rede que sigo: os alvos vulneráveis ficam exclusivamente em rede interna, sem NAT e sem bridge.

| Máquina | Papel | Endereço na rede interna |
|---|---|---|
| Kali Linux | Atacante | 192.168.56.10 |
| Metasploitable 2 | Alvo Linux | 192.168.56.20 |
| Metasploitable 3 (Ubuntu) | Alvo Linux mais realista | 192.168.56.30 |
| Metasploitable 3 (Windows Server 2008) | Alvo Windows | 192.168.56.40 |

Cada VM tem dois adaptadores. O adaptador 1 fica em rede interna (nome comum, tipo `labhack`) para o tráfego de ataque. O adaptador 2 fica em NAT, habilitado só no Kali e só quando preciso baixar algo. Os alvos nunca alcançam a internet, e eu confirmo isso: `ping -c 2 8.8.8.8` a partir do alvo tem que falhar.

## Modos de rede do VirtualBox

Saber para que serve cada modo é o que evita o erro clássico de expor uma máquina vulnerável.

| Modo | A VM enxerga | Quando uso |
|---|---|---|
| NAT | Internet, via host | Atualizar o Kali e baixar ferramenta |
| Rede interna | Só VMs do mesmo nome de rede | Modo padrão dos alvos, isolamento total |
| Host-only | VMs e o host | Acessar a interface web do OpenVAS a partir do host |
| Bridge | A rede física real | Evito com máquina vulnerável, colocaria o alvo na rede doméstica |

## Virtualização no hardware

Sem VT-x ou AMD-V habilitado na BIOS, VM de 64 bits não sobe. No Windows, Hyper-V, WSL2 e Core Isolation tomam o hipervisor e degradam o VirtualBox, então desativo esses recursos quando preciso ou migro o laboratório para o próprio Hyper-V. No Linux eu confiro com `egrep -c '(vmx|svm)' /proc/cpuinfo`, que precisa retornar valor maior que zero.

## Kali e snapshot zero

Subo o Kali pela imagem oficial pré-construída, ajusto rede conforme a topologia e, no primeiro login, troco a senha padrão na hora. A sequência que rodo logo de cara:

```bash
sudo apt update && sudo apt full-upgrade -y   # atualiza a distribuição
passwd                                        # troca a senha
ip a                                           # confere endereçamento
sudo apt install -y terminator                 # terminal com múltiplos painéis
```

Depois de tudo atualizado, tiro um snapshot chamado `base-limpa`. A partir daí, qualquer experimento destrutivo é reversível com um clique e eu nunca mais reinstalo do zero. Faço o mesmo com cada alvo, com um snapshot `estado-inicial`.

## A regra que eu não quebro

Metasploitable é software intencionalmente inseguro. Nunca em modo bridge, nunca com port forwarding, nunca ligado sem necessidade. Uma dessas VMs alcançável pela internet é comprometida em minutos, e a responsabilidade pelo que sai dela é de quem a expôs. Essa disciplina de isolamento é a mesma que eu aplico quando subo qualquer serviço real: por padrão, fechado, e só abre o que precisa estar aberto.
